from django.contrib.auth.forms import AuthenticationForm


class AuthForm(AuthenticationForm):
    pass
